<?php
$config['email'] = 'yo';
$config['password'] = '@@Support##';
?>
<?php
$config['email'] = 'YOUR_EMAIL';
$config['password'] = 'YOUR_PASSWORD';
?>
<div class="modal fade" id="dg-fonts" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>						
				<div class="btn-group">
					<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
						<?php echo lang('designer_fonts_font_categories'); ?> <span class="caret"></span>
					</button>
					<ul class="dropdown-menu font-categories" role="menu"></ul>
				</div>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-12 list-fonts"></div>
				</div>
			</div>
		</div>
	</div>
</div>